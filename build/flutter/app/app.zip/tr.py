# main.py (Flet Client App)
import flet as ft
import requests
import jwt

# For Flask-JWT-Extended (common in Flask APIs)
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from datetime import datetime, timedelta

# Configuration
API_BASE_URL = "http://127.0.0.1:8800/api/"
JWT_SECRET = "your-secret-key"  # Match Flask server's secret

class TranslationApp(ft.UserControl):
    def __init__(self, page):
        super().__init__()
        self.page = page
        self.auth_token = None
        self.current_session = None
        self.translations = []
        self.page.on_route_change = self.route_change

    def build(self):
        return ft.Container(
            expand=True,
            content=ft.Column(
                controls=[
                    self.login_view(),
                    self.translation_view(),
                    self.history_view()
                ]
            )
        )

    def login_view(self):
        return ft.Column(
            visible=True,
            controls=[
                ft.Text("Healthcare Translator", size=24, weight="bold"),
                ft.TextField(label="Email", id="email"),
                ft.TextField(label="Unique User ID", id="user_id"),
                ft.TextField(label="Password", password=True, id="password"),
                ft.ElevatedButton("Login", on_click=self.handle_login),
                ft.ElevatedButton("Register", on_click=self.show_register)
            ]
        )

    def translation_view(self):
        self.input_lang = ft.Dropdown(
            label="Input Language",
            options=[ft.dropdown.Option(k) for k in LANGUAGE_CODES.values()],
            value="English"
        )
        self.target_lang = ft.Dropdown(
            label="Target Language",
            options=[ft.dropdown.Option(k) for k in LANGUAGE_CODES.values()],
            value="English"
        )
        
        return ft.Column(
            visible=False,
            controls=[
                ft.Row([
                    self.input_lang,
                    self.target_lang,
                    ft.IconButton(ft.icons.TRANSLATE, on_click=self.toggle_translation)
                ]),
                ft.ElevatedButton("Start Recording", on_click=self.start_recording),
                ft.Text("Transcript will appear here", id="transcript"),
                ft.Text("Translation will appear here", id="translation"),
                ft.ElevatedButton("Generate Summary", on_click=self.generate_summary),
                ft.ElevatedButton("View History", on_click=self.show_history)
            ]
        )

    async def start_recording(self, e):
        # Implement speech-to-text using device capabilities
        transcript = await self.page.platform.invoke_method(
            "speech_recognition", 
            {"language": self.input_lang.value}
        )
        
        if transcript:
            self.translate_text(transcript)

    def translate_text(self, text):
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        data = {
            "session_id": self.current_session["id"],
            "text": text,
            "source_lang": self.get_lang_code(self.input_lang.value),
            "target_lang": self.get_lang_code(self.target_lang.value)
        }
        
        response = requests.post(
            f"{API_BASE_URL}translate",
            headers=headers,
            json=data
        )
        
        if response.status_code == 200:
            result = response.json()
            self.show_translation(text, result['translation']['translated_text'])
            self.translations.append(result['translation'])
        else:
            self.show_error("Translation failed")

    def show_translation(self, original, translated):
        self.page.controls[1].controls[3].value = original
        self.page.controls[1].controls[4].value = translated
        self.page.update()

    async def handle_login(self, e):
        login_data = {
            "email": self.page.get_control("email").value,
            "unique_user_id": self.page.get_control("user_id").value,
            "password": self.page.get_control("password").value
        }
        
        response = requests.post(f"{API_BASE_URL}login", json=login_data)
        
        if response.status_code == 200:
            data = response.json()
            self.auth_token = data['access_token']
            self.current_session = data['session']
            self.show_main_interface()
        else:
            self.show_error("Login failed")

    def show_main_interface(self):
        self.page.controls[0].visible = False
        self.page.controls[1].visible = True
        self.page.update()

    def generate_summary(self, e):
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        data = {"session_id": self.current_session["id"]}
        
        response = requests.post(
            f"{API_BASE_URL}generate_summary",
            headers=headers,
            json=data
        )
        
        if response.status_code == 200:
            self.show_summary(response.json()['summary'])
        else:
            self.show_error("Summary generation failed")

    def show_history(self, e):
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        response = requests.get(
            f"{API_BASE_URL}translations?user_id={self.current_session['user_id']}",
            headers=headers
        )
        
        if response.status_code == 200:
            self.display_history(response.json()['translations'])
        else:
            self.show_error("Failed to load history")

    def get_lang_code(self, lang_name):
        return [k for k, v in LANGUAGE_CODES.items() if v == lang_name][0]

    # Add remaining helper methods and views...

def main(page: ft.Page):
    page.title = "Healthcare Translator"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.add(TranslationApp(page))
    
    # Configure Android-specific settings
    if page.platform == "android":
        page.platform.configure_android(
            package_name="com.example.healthcare_translator",
            version_code=1,
            version_name="1.0",
            permissions=[ft.AndroidPermission.RECORD_AUDIO]
        )

ft.app(target=main, view=ft.AppView.WEB_BROWSER)