from PIL import Image
import os

def resize_icon(input_path, output_path, size):
    with Image.open(input_path) as img:
        # Convert to RGBA if not already
        img = img.convert('RGBA')
        # Resize with high quality
        img = img.resize((size, size), Image.Resampling.LANCZOS)
        img.save(output_path, 'PNG')

def main():
    # Get the directory of this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    assets_dir = os.path.join(base_dir, 'assets')
    
    # Create assets directory if it doesn't exist
    os.makedirs(assets_dir, exist_ok=True)
    
    # Source icon path
    source_icon = os.path.join(assets_dir, 'icon.png')
    
    # Generate different sizes
    sizes = {
        'icon-192.png': 192,
        'icon-512.png': 512
    }
    
    for filename, size in sizes.items():
        output_path = os.path.join(assets_dir, filename)
        resize_icon(source_icon, output_path, size)
        print(f"Created {filename} ({size}x{size})")

if __name__ == '__main__':
    main() 